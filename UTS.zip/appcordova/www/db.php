<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","id7899380_sertifikasi","sertifikasi","id7899380_sertifikasi") or die ("could not connect database");
?>
